#!C:\Data\Southpaw\TacticStandalone\tactic-4.0-python-2.6-Dev\python\python.exe
# EASY-INSTALL-ENTRY-SCRIPT: 'watchdog==0.6.0','console_scripts','watchmedo'
__requires__ = 'watchdog==0.6.0'
import sys
from pkg_resources import load_entry_point

sys.exit(
   load_entry_point('watchdog==0.6.0', 'console_scripts', 'watchmedo')()
)
